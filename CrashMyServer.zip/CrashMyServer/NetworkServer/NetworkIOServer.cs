﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// Here are some network libraries ...
using System.Net;
using System.Net.Sockets;
// And our IO friends from file manipulation
using System.IO;
using System.Threading;

// TCP/IP Server
// Code strongly based on Liberty & Xie p. 514.
// Performs one exchange and quits.
// KG

namespace NetworkServer
{
    class NetworkIOServer
    {
        public const int MY_PORT = 2112;  // may need to change this if it's blocked or something

        static void Main(string[] args)
        {
			// Get an ip address
			Console.Write("Enter IP Address: ");
			string ipAddress = Console.ReadLine();
            NetworkIOServer myServer = new NetworkIOServer();
            myServer.Run(ipAddress);
        }

        // Main server method.  Runs until it gets a connection, gets and sends one message,
        // and exits.
        public void Run(string ipAddress)
        {
            
            // This line turns the string into an IPAddress object
            // (notice consistency in method naming:  Parse)
            IPAddress address = IPAddress.Parse(ipAddress);
            TcpListener tcpListener = new TcpListener(address, MY_PORT);
            tcpListener.Start();

            while (true)
            {
                try
                {
                    Console.WriteLine("Listening for connections....");

                    // Next line will block (stall) until we get someone connecting
                    Socket socket = tcpListener.AcceptSocket();

                    // create the ConnectionThread object to handle all the processing
                    ConnectionThread ct = new ConnectionThread(socket);

                    // create a thread and start it
                    Thread t = new Thread(new ThreadStart(ct.Serve));
                    t.Start();
                    
                    // go back and wait for the next connection
                }
                catch (Exception e)
                {
                    // This can happen if the client disconnects in the middle of the conversation, for example
                    Console.WriteLine(e.Message);
                    Console.WriteLine(e.StackTrace);
                }
            }
        }
    }
}
