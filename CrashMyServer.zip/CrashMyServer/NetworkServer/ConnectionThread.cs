﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;

namespace NetworkServer
{
    // The Run method is a separate thread for each connection
    class ConnectionThread
    {
        // attribute
        private Socket sock;
        static int id = 0;


        // constructor - get socket after connection is made
        public ConnectionThread(Socket skt)
        {
            sock = skt;
            id++; 
        }

        // method to handle connection
        public void Serve()
        {
            try
            {
                // Here's how to read one line ... more is an exercise for the reader
                // BTW, these readers and writers with long names are one exceptional case in which
                // I think it's ok to use 2-letter abbreviations for var names ... others may disagree
                StreamReader sr = new StreamReader(new NetworkStream(sock));
                Console.Write("Reading line: Thread# " + id + " ");
                string line = sr.ReadLine();
                //if (line.Length < 80)
                //{
                Console.WriteLine(line);
                // }
                //else
                //{
                //    Console.WriteLine("long line of data");
                //}

                // Create a response message
                string myMessage = "Thread# " + id + " received your message";

                // And here's how to write a line
                StreamWriter sw = new StreamWriter(new NetworkStream(sock));
                sw.WriteLine(myMessage);

                // Flush means "send all this right away, don't wait for a full buffer".  Forgetting it
                // will lead to your code just sitting there with stuff in the pipe, ready to go!  On the other
                // hand, if you plan to do a lot of writing, only call this once you're ready to send ... this
                // can result in faster transmission
                sw.Flush();

                // Lots of printouts can help figure out what's going on in a network situation...
                // so many things can go wrong that lead to it just sitting there!
                Console.WriteLine("Disconnecting....");

                // Like files, sockets should be closed.  This frees up the port.
                sock.Close();
            }
                // added by KJB to stop an uncaught exception that brought the
                // server down
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in Run: " + ex.Message);
            }
            finally
            {
                if (sock != null)
                    sock.Close();
            }
        }
    }
}
